import React from 'react';
import { Logo } from '../components/Logo';
import { SearchBar } from '../components/SearchBar';
import { AIOverview } from '../components/AIOverview';
import { SourceCard } from '../components/SourceCard';
import { MapsCard } from '../components/MapsCard';
import { SearchResult, SearchStatus } from '../types';

interface ResultsViewProps {
  query: string;
  onSearch: (query: string) => void;
  status: SearchStatus;
  result: SearchResult | null;
  onLogoClick: () => void;
}

export const ResultsView: React.FC<ResultsViewProps> = ({ query, onSearch, status, result, onLogoClick }) => {
  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      {/* Top Navigation */}
      <div className="bg-white/80 backdrop-blur-lg border-b border-slate-200 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 md:px-6 py-3 flex items-center gap-6">
            <div className="hidden md:block">
                <Logo size="small" onClick={onLogoClick} />
            </div>
            <div className="flex-grow max-w-2xl">
                <SearchBar initialQuery={query} onSearch={onSearch} />
            </div>
            <div className="ml-auto flex items-center gap-4">
                 <button className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                        <path fillRule="evenodd" d="M3 6.75A.75.75 0 013.75 6h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 6.75zM3 12a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 12zm0 5.25a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75a.75.75 0 01-.75-.75z" clipRule="evenodd" />
                    </svg>
                 </button>
            </div>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-6 py-8">
        {status === SearchStatus.LOADING && (
            <div className="max-w-4xl mx-auto space-y-8 animate-pulse">
                <div className="h-64 bg-white rounded-2xl border border-slate-200 shadow-sm"></div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="h-32 bg-slate-200 rounded-xl"></div>
                    <div className="h-32 bg-slate-200 rounded-xl"></div>
                    <div className="h-32 bg-slate-200 rounded-xl"></div>
                </div>
            </div>
        )}

        {status === SearchStatus.ERROR && (
            <div className="max-w-2xl mx-auto p-6 bg-red-50 text-red-700 rounded-xl border border-red-200 text-center">
                <h3 className="font-semibold mb-1">Something went wrong</h3>
                <p className="text-sm">We couldn't generate an answer for you. Please try again.</p>
            </div>
        )}

        {status === SearchStatus.SUCCESS && result && (
            <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
                
                {/* Main Content: AI Answer */}
                <div className="lg:col-span-8 space-y-8">
                    <AIOverview text={result.text} />
                </div>

                {/* Sidebar: Sources Grid */}
                <div className="lg:col-span-4">
                    
                    {/* Maps Section */}
                    {result.groundingMetadata?.groundingChunks?.some(c => c.maps) && (
                        <div className="mb-6">
                            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 px-1">Places</h3>
                            <div className="grid grid-cols-1 gap-3">
                                {result.groundingMetadata.groundingChunks
                                    .filter(c => c.maps)
                                    .map((chunk, idx) => (
                                        <MapsCard key={`map-${idx}`} chunk={chunk} />
                                    ))
                                }
                            </div>
                        </div>
                    )}

                    {/* Web Sources Section */}
                    <div>
                        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 px-1">Sources</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-3">
                            {result.groundingMetadata?.groundingChunks
                                ?.filter(c => c.web)
                                .map((chunk, idx) => (
                                    <SourceCard key={idx} chunk={chunk} index={idx} />
                            ))}
                            {(!result.groundingMetadata?.groundingChunks || !result.groundingMetadata.groundingChunks.some(c => c.web)) && (
                                <div className="text-slate-400 text-sm italic px-2">No direct web sources found.</div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};