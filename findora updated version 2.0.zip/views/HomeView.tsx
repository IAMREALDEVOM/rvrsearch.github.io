import React, { useEffect, useState } from 'react';
import { Logo } from '../components/Logo';
import { SearchBar } from '../components/SearchBar';
import { DashboardWidgets } from '../components/DashboardWidgets';
import { getDashboardData } from '../services/geminiService';
import { DashboardData } from '../types';

interface HomeViewProps {
  onSearch: (query: string) => void;
  onNavigateLabs: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onSearch, onNavigateLabs }) => {
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [loadingDashboard, setLoadingDashboard] = useState(true);

  useEffect(() => {
    // 1. Try to get user location
    const fetchDashboard = async (lat?: number, lon?: number) => {
      try {
        const data = await getDashboardData(lat, lon);
        setDashboardData(data);
      } catch (e) {
        console.error("Failed to load dashboard", e);
      } finally {
        setLoadingDashboard(false);
      }
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          fetchDashboard(position.coords.latitude, position.coords.longitude);
        },
        (error) => {
          console.log("Geolocation denied or error, falling back to default", error);
          fetchDashboard(); // Fallback to generic/global
        }
      );
    } else {
      fetchDashboard();
    }
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col overflow-x-hidden bg-slate-50 font-sans">
      {/* Background Blobs */}
      <div className="absolute top-[-10%] right-[-5%] w-[500px] h-[500px] bg-purple-200/40 rounded-full blur-[100px] pointer-events-none mix-blend-multiply animate-blob"></div>
      <div className="absolute bottom-[-10%] left-[-5%] w-[500px] h-[500px] bg-indigo-200/40 rounded-full blur-[100px] pointer-events-none mix-blend-multiply animate-blob animation-delay-2000"></div>

      {/* Header */}
      <header className="flex justify-end p-6 z-10">
        <nav className="flex items-center gap-6 text-sm font-medium text-slate-600">
            <a href="#" className="hover:text-indigo-600 transition-colors">About</a>
            <button onClick={onNavigateLabs} className="text-indigo-600 hover:text-indigo-800 transition-colors font-semibold flex items-center gap-1">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                Labs
            </button>
            <button className="px-4 py-2 rounded-full bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-sm transition-all text-slate-800">
                Sign In
            </button>
        </nav>
      </header>

      {/* Main Content */}
      <main className="flex-grow flex flex-col items-center justify-start pt-10 md:pt-20 px-4 pb-20 z-10">
        <div className="mb-8 transform hover:scale-105 transition-transform duration-500">
            <Logo />
        </div>
        
        <div className="w-full max-w-2xl">
            <SearchBar onSearch={onSearch} centered />
            
            <div className="mt-6 flex flex-wrap justify-center gap-3 text-sm">
                 {/* Chips can go here if needed, keeping it clean for dashboard */}
            </div>
        </div>

        {/* Dashboard Widgets */}
        <DashboardWidgets data={dashboardData} loading={loadingDashboard} />

      </main>

      {/* Footer */}
      <footer className="py-6 text-center text-slate-400 text-xs z-10">
        <p>&copy; {new Date().getFullYear()} Findora AI.</p>
      </footer>
      
      {/* Add subtle animation styles */}
      <style>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .fade-in-up {
          animation: fadeInUp 0.5s ease-out forwards;
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};