import React, { useState } from 'react';
import { Logo } from '../components/Logo';
import { MarkdownView } from '../components/MarkdownView';
import { LiveInterface } from '../components/LiveInterface';
import { askReasoningAI, generateImage } from '../services/geminiService';
import { AspectRatio } from '../types';

interface LabsViewProps {
  onHomeClick: () => void;
}

type Tab = 'reasoning' | 'image' | 'live';

export const LabsView: React.FC<LabsViewProps> = ({ onHomeClick }) => {
  const [activeTab, setActiveTab] = useState<Tab>('reasoning');
  
  // Reasoning State
  const [input, setInput] = useState('');
  const [response, setResponse] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  // Image State
  const [imgPrompt, setImgPrompt] = useState('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [generatedImg, setGeneratedImg] = useState<string | null>(null);
  const [imgLoading, setImgLoading] = useState(false);

  // Handlers
  const handleReasoningSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    setLoading(true);
    setResponse(null);
    try {
      const result = await askReasoningAI(input);
      setResponse(result);
    } catch (error) {
      setResponse("System error: Neural link unstable.");
    } finally {
      setLoading(false);
    }
  };

  const handleImageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imgPrompt.trim()) return;
    setImgLoading(true);
    setGeneratedImg(null);
    try {
      const result = await generateImage(imgPrompt, aspectRatio);
      setGeneratedImg(result);
    } catch (error) {
      alert("Failed to generate image.");
    } finally {
      setImgLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 font-mono flex flex-col">
      {/* Header */}
      <header className="border-b border-slate-800 p-4 flex items-center justify-between sticky top-0 bg-slate-900/90 backdrop-blur z-20">
        <div className="flex items-center gap-3 cursor-pointer" onClick={onHomeClick}>
           <div className="w-8 h-8 rounded bg-indigo-600 flex items-center justify-center font-bold text-white">F</div>
           <span className="font-bold tracking-widest text-indigo-400">FINDORA<span className="text-white">LABS</span></span>
        </div>
        
        {/* Tab Navigation */}
        <div className="hidden md:flex gap-1 bg-slate-800 p-1 rounded-lg">
            {(['reasoning', 'image', 'live'] as Tab[]).map((tab) => (
                <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-4 py-1.5 rounded-md text-xs font-bold uppercase tracking-wider transition-all ${
                        activeTab === tab 
                        ? 'bg-indigo-600 text-white shadow-lg' 
                        : 'text-slate-400 hover:text-white hover:bg-slate-700'
                    }`}
                >
                    {tab}
                </button>
            ))}
        </div>

        <button onClick={onHomeClick} className="text-xs text-slate-500 hover:text-white uppercase tracking-widest transition-colors">
            Exit
        </button>
      </header>
      
      {/* Mobile Tab Nav */}
      <div className="md:hidden flex border-b border-slate-800">
         {(['reasoning', 'image', 'live'] as Tab[]).map((tab) => (
            <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider ${
                    activeTab === tab ? 'text-indigo-400 border-b-2 border-indigo-500' : 'text-slate-500'
                }`}
            >
                {tab}
            </button>
         ))}
      </div>

      {/* Content Area */}
      <main className="flex-grow flex flex-col items-center p-4 md:p-8 max-w-5xl mx-auto w-full h-full">
        
        {/* REASONING TAB */}
        {activeTab === 'reasoning' && (
            <div className="w-full max-w-3xl space-y-8 animate-fade-in">
                <div className="text-center space-y-4 mb-8">
                     <h2 className="text-2xl font-bold text-indigo-400">Deep Reasoning Engine</h2>
                     <p className="text-slate-500 text-sm">Powered by Gemini 3 Pro • 32k Thinking Budget</p>
                </div>

                {(response || loading) && (
                    <div className="w-full bg-slate-800/50 rounded-lg border border-slate-700 p-6 shadow-2xl relative overflow-hidden">
                        {loading && <div className="absolute inset-0 bg-gradient-to-b from-transparent via-indigo-500/5 to-transparent h-2 w-full animate-scan pointer-events-none"></div>}
                        {loading ? (
                             <div className="text-center py-12 text-indigo-400 animate-pulse tracking-widest text-xs">THINKING...</div>
                        ) : (
                             <MarkdownView content={response || ''} />
                        )}
                    </div>
                )}

                <form onSubmit={handleReasoningSubmit} className="relative">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Ask a complex question..."
                        className="w-full bg-slate-900 border-2 border-slate-700 text-white rounded-xl p-4 pr-16 focus:outline-none focus:border-indigo-500 transition-all placeholder-slate-600"
                        disabled={loading}
                    />
                    <button type="submit" disabled={!input.trim() || loading} className="absolute right-3 top-3 p-2 bg-indigo-600 rounded-lg hover:bg-indigo-500 disabled:opacity-50 text-white">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </button>
                </form>
            </div>
        )}

        {/* IMAGE TAB */}
        {activeTab === 'image' && (
             <div className="w-full max-w-3xl space-y-8 animate-fade-in">
                 <div className="text-center space-y-4 mb-8">
                     <h2 className="text-2xl font-bold text-pink-400">Creative Studio</h2>
                     <p className="text-slate-500 text-sm">Gemini 3 Pro Image Preview</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-6">
                        <form onSubmit={handleImageSubmit} className="space-y-4">
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Prompt</label>
                                <textarea 
                                    value={imgPrompt}
                                    onChange={e => setImgPrompt(e.target.value)}
                                    className="w-full bg-slate-800 border border-slate-700 rounded-lg p-3 text-white focus:border-pink-500 outline-none h-32 resize-none"
                                    placeholder="Describe the image you want to create..."
                                />
                            </div>
                            
                            <div>
                                <label className="block text-xs font-bold text-slate-500 uppercase mb-2">Aspect Ratio</label>
                                <div className="grid grid-cols-5 gap-2">
                                    {(['1:1', '3:4', '4:3', '9:16', '16:9'] as AspectRatio[]).map(ratio => (
                                        <button
                                            key={ratio}
                                            type="button"
                                            onClick={() => setAspectRatio(ratio)}
                                            className={`text-xs py-2 rounded border ${aspectRatio === ratio ? 'border-pink-500 bg-pink-500/10 text-pink-400' : 'border-slate-700 text-slate-500 hover:border-slate-600'}`}
                                        >
                                            {ratio}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <button type="submit" disabled={imgLoading || !imgPrompt} className="w-full py-3 bg-pink-600 hover:bg-pink-500 rounded-lg font-bold text-white transition-colors disabled:opacity-50">
                                {imgLoading ? 'GENERATING...' : 'GENERATE'}
                            </button>
                        </form>
                    </div>

                    <div className="bg-black/50 rounded-xl border border-slate-800 flex items-center justify-center min-h-[300px] overflow-hidden">
                        {imgLoading ? (
                             <div className="w-8 h-8 border-2 border-pink-500 border-t-transparent rounded-full animate-spin"></div>
                        ) : generatedImg ? (
                             <img src={generatedImg} alt="Generated" className="w-full h-full object-contain" />
                        ) : (
                             <div className="text-slate-600 text-xs uppercase tracking-widest">No Image Generated</div>
                        )}
                    </div>
                </div>
             </div>
        )}

        {/* LIVE TAB */}
        {activeTab === 'live' && (
             <div className="w-full max-w-lg h-[600px] animate-fade-in">
                 <div className="text-center space-y-2 mb-6">
                     <h2 className="text-2xl font-bold text-green-400">Live Connection</h2>
                     <p className="text-slate-500 text-sm">Real-time Multimodal Native Audio</p>
                </div>
                <div className="h-full border border-slate-800 rounded-3xl shadow-2xl">
                    <LiveInterface onClose={() => setActiveTab('reasoning')} />
                </div>
             </div>
        )}

      </main>

      <style>{`
        @keyframes scan { 0% { top: -20%; } 100% { top: 120%; } }
        .animate-scan { animation: scan 2s linear infinite; }
        .animate-fade-in { animation: fadeIn 0.3s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};