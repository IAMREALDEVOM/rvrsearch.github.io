import { GoogleGenAI } from "@google/genai";
import { SearchResult, DashboardData, AspectRatio } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const performSearch = async (query: string): Promise<SearchResult> => {
  try {
    // Adding googleMaps tool alongside googleSearch
    // Also requesting user location if available (mocked here, in prod pass actual coords)
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        tools: [{ googleSearch: {} }, { googleMaps: {} }],
      },
    });

    const candidate = response.candidates?.[0];
    if (!candidate) {
      throw new Error("No response from AI");
    }

    const text = candidate.content?.parts?.map(p => p.text).join('') || "";
    const groundingMetadata = candidate.groundingMetadata as any;

    return {
      text,
      groundingMetadata,
    };
  } catch (error) {
    console.error("Search failed:", error);
    throw error;
  }
};

export const getDashboardData = async (lat?: number, lon?: number): Promise<DashboardData> => {
  try {
    const locationPrompt = lat && lon ? `at latitude ${lat}, longitude ${lon}` : "for a major global city like New York";
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Find the current weather ${locationPrompt}. Also find 3 top news headlines relevant to that location. 
      
      Return ONLY a raw JSON string. Structure:
      {
        "weather": { "location": "City", "temperature": "24°C", "condition": "Sunny" },
        "news": [ { "headline": "Title", "source": "Source", "time": "2h ago" } ]
      }`,
      config: {
        tools: [{ googleSearch: {} }],
      }
    });

    let text = response.text || "";
    text = text.replace(new RegExp('```json', 'g'), '').replace(new RegExp('```', 'g'), '').trim();

    if (!text) throw new Error("No data received");
    
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start !== -1 && end !== -1) {
        text = text.substring(start, end + 1);
    }

    return JSON.parse(text) as DashboardData;
  } catch (error) {
    console.error("Dashboard fetch failed:", error);
    return {
      weather: { location: "Unknown", temperature: "--", condition: "Cloudy" },
      news: []
    };
  }
};

export const askReasoningAI = async (prompt: string): Promise<string> => {
  try {
    // Updated to use gemini-3-pro-preview with high thinking budget
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
      }
    });
    return response.text || "I processed that, but couldn't formulate a response.";
  } catch (error) {
    console.error("Reasoning AI failed:", error);
    throw error;
  }
};

export const generateImage = async (prompt: string, aspectRatio: AspectRatio): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
          imageSize: "1K"
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated");
  } catch (error) {
    console.error("Image generation failed:", error);
    throw error;
  }
};

export const getLiveClient = () => {
    return ai.live;
};