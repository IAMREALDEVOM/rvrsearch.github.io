import React, { useState } from 'react';
import { HomeView } from './views/HomeView';
import { ResultsView } from './views/ResultsView';
import { LabsView } from './views/LabsView';
import { performSearch } from './services/geminiService';
import { SearchResult, SearchStatus } from './types';

type ViewState = 'home' | 'results' | 'labs';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('home');
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState<SearchStatus>(SearchStatus.IDLE);
  const [result, setResult] = useState<SearchResult | null>(null);

  const handleSearch = async (newQuery: string) => {
    setQuery(newQuery);
    setCurrentView('results');
    setStatus(SearchStatus.LOADING);
    setResult(null);

    try {
      const data = await performSearch(newQuery);
      setResult(data);
      setStatus(SearchStatus.SUCCESS);
    } catch (error) {
      console.error(error);
      setStatus(SearchStatus.ERROR);
    }
  };

  const handleLogoClick = () => {
    setQuery('');
    setStatus(SearchStatus.IDLE);
    setResult(null);
    setCurrentView('home');
  };

  const handleNavigateLabs = () => {
    setCurrentView('labs');
  };

  if (currentView === 'labs') {
    return <LabsView onHomeClick={handleLogoClick} />;
  }

  if (currentView === 'results') {
    return (
      <ResultsView 
        query={query} 
        onSearch={handleSearch} 
        status={status} 
        result={result}
        onLogoClick={handleLogoClick}
      />
    );
  }

  return <HomeView onSearch={handleSearch} onNavigateLabs={handleNavigateLabs} />;
}

export default App;