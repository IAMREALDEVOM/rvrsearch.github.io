export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
  maps?: {
    uri: string;
    title: string;
    placeAnswerSources?: {
        reviewSnippets?: {
            snippet: string;
            author: string;
        }[]
    }
  }
}

export interface GroundingMetadata {
  groundingChunks: GroundingChunk[];
  groundingSupports?: any[];
  searchEntryPoint?: {
    renderedContent: string;
  };
  webSearchQueries?: string[];
}

export interface SearchResult {
  text: string;
  groundingMetadata?: GroundingMetadata;
}

export enum SearchStatus {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}

export interface WeatherData {
  location: string;
  temperature: string;
  condition: string;
  icon?: string; 
}

export interface NewsItem {
  headline: string;
  source: string;
  time: string;
}

export interface DashboardData {
  weather: WeatherData;
  news: NewsItem[];
}

export type AspectRatio = "1:1" | "3:4" | "4:3" | "9:16" | "16:9";