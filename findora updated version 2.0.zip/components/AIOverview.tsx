import React from 'react';
import { GroundingChunk } from '../types';
import { MarkdownView } from './MarkdownView';

interface AIOverviewProps {
  text: string;
}

export const AIOverview: React.FC<AIOverviewProps> = ({ text }) => {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-indigo-100 bg-white shadow-sm ring-1 ring-black/5">
      {/* Decorative gradient header */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
      
      <div className="p-6 md:p-8">
        <div className="flex items-center gap-2 mb-6">
           <div className="w-6 h-6 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
               <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                  <path fillRule="evenodd" d="M9 4.5a.75.75 0 01.721.544l.813 2.846a3.75 3.75 0 002.576 2.576l2.846.813a.75.75 0 010 1.442l-2.846.813a3.75 3.75 0 00-2.576 2.576l-.813 2.846a.75.75 0 01-1.442 0l-.813-2.846a3.75 3.75 0 00-2.576-2.576l-2.846-.813a.75.75 0 010-1.442l2.846-.813a3.75 3.75 0 002.576-2.576l.813-2.846A.75.75 0 019 4.5zM6.97 11.03a.75.75 0 111.06-1.06l1.062 1.06a.75.75 0 11-1.061 1.062l-1.061-1.06z" clipRule="evenodd" />
               </svg>
           </div>
           <span className="font-semibold text-slate-800 text-sm tracking-wide">AI Summary</span>
        </div>
        
        {/* Added text-slate-700 explicitly here since it was removed from MarkdownView */}
        <div className="prose prose-slate max-w-none text-slate-700">
            <MarkdownView content={text} />
        </div>
      </div>
    </div>
  );
};