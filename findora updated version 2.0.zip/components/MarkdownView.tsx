import React from 'react';

interface MarkdownViewProps {
  content: string;
}

export const MarkdownView: React.FC<MarkdownViewProps> = ({ content }) => {
  // Simple parser to handle bold, basic lists, and paragraphs.
  // This avoids complex dependencies while fixing the "glitchy" text look.
  
  const parseText = (text: string) => {
    // Replace **bold** with <strong>bold</strong>
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold opacity-90">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  
  let listBuffer: React.ReactNode[] = [];
  let inList = false;

  lines.forEach((line, index) => {
    const trimmed = line.trim();
    
    // Header detection
    if (trimmed.startsWith('## ')) {
        if (inList) {
            elements.push(<ul key={`list-${index}`} className="list-disc pl-5 mb-4 space-y-1 opacity-90">{listBuffer}</ul>);
            listBuffer = [];
            inList = false;
        }
        elements.push(<h2 key={index} className="text-xl font-bold mt-6 mb-3 opacity-95">{parseText(trimmed.replace(/^##\s+/, ''))}</h2>);
        return;
    }

    // List detection
    if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
      inList = true;
      listBuffer.push(
        <li key={`li-${index}`} className="pl-1">
          {parseText(trimmed.replace(/^[\*\-]\s+/, ''))}
        </li>
      );
    } else {
      // Close list if open
      if (inList) {
        elements.push(<ul key={`list-${index}`} className="list-disc pl-5 mb-4 space-y-1 opacity-90">{listBuffer}</ul>);
        listBuffer = [];
        inList = false;
      }
      
      // Regular paragraph (ignore empty lines unless they separate content)
      if (trimmed.length > 0) {
        elements.push(<p key={index} className="mb-4 leading-relaxed opacity-90">{parseText(trimmed)}</p>);
      }
    }
  });

  // Flush remaining list
  if (inList) {
    elements.push(<ul key="list-end" className="list-disc pl-5 mb-4 space-y-1 opacity-90">{listBuffer}</ul>);
  }

  return <div className="text-[15px] md:text-[16px]">{elements}</div>;
};