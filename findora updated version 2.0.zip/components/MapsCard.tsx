import React from 'react';
import { GroundingChunk } from '../types';

interface MapsCardProps {
  chunk: GroundingChunk;
}

export const MapsCard: React.FC<MapsCardProps> = ({ chunk }) => {
  if (!chunk.maps) return null;

  const { title, uri } = chunk.maps;
  
  // Extract lat/long or place ID from URI if possible, or use a static map preview approach
  // For now, we will link to the map and show a map-style card
  
  return (
    <a 
      href={uri} 
      target="_blank" 
      rel="noopener noreferrer"
      className="flex flex-col bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-indigo-300 hover:shadow-md transition-all duration-200 h-full group"
    >
      <div className="h-24 bg-slate-100 relative overflow-hidden">
          {/* Simulated Map Background Pattern */}
          <div className="absolute inset-0 opacity-20" style={{
              backgroundImage: 'radial-gradient(#CBD5E1 1px, transparent 1px)',
              backgroundSize: '10px 10px'
          }}></div>
          <div className="absolute inset-0 flex items-center justify-center">
             <div className="w-8 h-8 rounded-full bg-red-500 shadow-lg flex items-center justify-center text-white animate-bounce">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                    <path fillRule="evenodd" d="M11.54 22.351l.07.04.028.016a.76.76 0 00.723 0l.028-.015.071-.041a16.975 16.975 0 001.144-.742 19.58 19.58 0 002.683-2.282c1.944-1.99 3.963-4.98 3.963-8.827a8.25 8.25 0 00-16.5 0c0 3.846 2.02 6.837 3.963 8.827a19.58 19.58 0 002.682 2.282 16.975 16.975 0 001.145.742zM12 13.5a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                </svg>
             </div>
          </div>
      </div>
      <div className="p-4">
        <h3 className="text-sm font-semibold text-slate-900 group-hover:text-indigo-600 truncate">
            {title}
        </h3>
        <div className="text-xs text-slate-500 mt-1 flex items-center gap-1">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
            Google Maps
        </div>
      </div>
    </a>
  );
};