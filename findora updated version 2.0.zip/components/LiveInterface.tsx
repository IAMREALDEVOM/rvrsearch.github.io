import React, { useEffect, useRef, useState } from 'react';
import { getLiveClient } from '../services/geminiService';
import { LiveServerMessage, Modality } from '@google/genai';

interface LiveInterfaceProps {
    onClose: () => void;
}

export const LiveInterface: React.FC<LiveInterfaceProps> = ({ onClose }) => {
    const [status, setStatus] = useState<'connecting' | 'connected' | 'error' | 'disconnected'>('connecting');
    const [transcripts, setTranscripts] = useState<{role: 'user'|'model', text: string}[]>([]);
    
    // Refs for audio handling
    const audioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const processorRef = useRef<ScriptProcessorNode | null>(null);
    const inputSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const nextStartTimeRef = useRef<number>(0);

    useEffect(() => {
        let isMounted = true;

        const startSession = async () => {
            try {
                // Initialize Audio Contexts
                const AudioContextClass = (window as any).AudioContext || (window as any).webkitAudioContext;
                const inputCtx = new AudioContextClass({ sampleRate: 16000 });
                const outputCtx = new AudioContextClass({ sampleRate: 24000 });
                audioContextRef.current = outputCtx; // Store output context for playback

                // Get User Media
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaStreamRef.current = stream;

                // Helper to create PCM Blob
                const createBlob = (data: Float32Array) => {
                    const l = data.length;
                    const int16 = new Int16Array(l);
                    for (let i = 0; i < l; i++) {
                        int16[i] = data[i] * 32768;
                    }
                    const uint8 = new Uint8Array(int16.buffer);
                    let binary = '';
                    const len = uint8.byteLength;
                    for (let i = 0; i < len; i++) {
                        binary += String.fromCharCode(uint8[i]);
                    }
                    const b64 = btoa(binary);
                    
                    return {
                        data: b64,
                        mimeType: 'audio/pcm;rate=16000',
                    };
                };

                // Decode Helper
                const decodeAudioData = async (b64: string, ctx: AudioContext) => {
                   const binaryString = atob(b64);
                   const len = binaryString.length;
                   const bytes = new Uint8Array(len);
                   for(let i=0; i<len; i++) bytes[i] = binaryString.charCodeAt(i);
                   
                   const dataInt16 = new Int16Array(bytes.buffer);
                   const frameCount = dataInt16.length;
                   const buffer = ctx.createBuffer(1, frameCount, 24000);
                   const channelData = buffer.getChannelData(0);
                   for(let i=0; i<frameCount; i++) {
                       channelData[i] = dataInt16[i] / 32768.0;
                   }
                   return buffer;
                };

                const client = getLiveClient();

                const sessionPromise = client.connect({
                    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                    config: {
                        responseModalities: [Modality.AUDIO],
                        speechConfig: {
                            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
                        },
                        systemInstruction: "You are Findora's friendly voice assistant.",
                        inputAudioTranscription: {},
                        outputAudioTranscription: {}
                    },
                    callbacks: {
                        onopen: () => {
                            if (isMounted) setStatus('connected');
                            
                            // Setup Input Streaming
                            const source = inputCtx.createMediaStreamSource(stream);
                            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
                            
                            scriptProcessor.onaudioprocess = (e) => {
                                const inputData = e.inputBuffer.getChannelData(0);
                                const pcmBlob = createBlob(inputData);
                                sessionPromise.then(session => {
                                    session.sendRealtimeInput({ media: pcmBlob });
                                });
                            };
                            
                            source.connect(scriptProcessor);
                            scriptProcessor.connect(inputCtx.destination);
                            
                            inputSourceRef.current = source;
                            processorRef.current = scriptProcessor;
                        },
                        onmessage: async (msg: LiveServerMessage) => {
                            if (!isMounted) return;

                            // Handle Transcription
                            if (msg.serverContent?.outputTranscription?.text) {
                                setTranscripts(prev => [...prev, {role: 'model', text: msg.serverContent!.outputTranscription!.text}]);
                            }
                            if (msg.serverContent?.inputTranscription?.text) {
                                setTranscripts(prev => [...prev, {role: 'user', text: msg.serverContent!.inputTranscription!.text}]);
                            }

                            // Handle Audio Output
                            const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                            if (audioData) {
                                const buffer = await decodeAudioData(audioData, outputCtx);
                                const source = outputCtx.createBufferSource();
                                source.buffer = buffer;
                                source.connect(outputCtx.destination);
                                
                                const currentTime = outputCtx.currentTime;
                                const startTime = Math.max(nextStartTimeRef.current, currentTime);
                                source.start(startTime);
                                nextStartTimeRef.current = startTime + buffer.duration;
                            }
                        },
                        onclose: () => {
                            if (isMounted) setStatus('disconnected');
                        },
                        onerror: (e) => {
                            console.error(e);
                            if (isMounted) setStatus('error');
                        }
                    }
                });
                sessionPromiseRef.current = sessionPromise;

            } catch (err) {
                console.error("Failed to start live session", err);
                setStatus('error');
            }
        };

        startSession();

        return () => {
            isMounted = false;
            // Cleanup
            if (mediaStreamRef.current) {
                mediaStreamRef.current.getTracks().forEach(t => t.stop());
            }
            if (processorRef.current && inputSourceRef.current) {
                inputSourceRef.current.disconnect();
                processorRef.current.disconnect();
            }
            if (sessionPromiseRef.current) {
                // No explicit close on promise, depends on client implementation, 
                // but we stop sending audio.
            }
            if (audioContextRef.current) {
                audioContextRef.current.close();
            }
        };
    }, []);

    return (
        <div className="flex flex-col h-full bg-black rounded-3xl overflow-hidden relative">
            {/* Visualizer Background */}
            <div className="absolute inset-0 flex items-center justify-center opacity-30">
                <div className={`w-64 h-64 rounded-full blur-3xl transition-colors duration-1000 ${status === 'connected' ? 'bg-indigo-500 animate-pulse' : 'bg-red-900'}`}></div>
            </div>

            {/* Header */}
            <div className="relative z-10 p-6 flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${status === 'connected' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-white font-mono text-sm uppercase tracking-wider">
                        {status === 'connected' ? 'Live Signal Active' : status}
                    </span>
                </div>
                <button onClick={onClose} className="text-white/50 hover:text-white">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
            </div>

            {/* Conversation Log */}
            <div className="relative z-10 flex-grow overflow-y-auto p-6 space-y-4">
                {transcripts.length === 0 && status === 'connected' && (
                    <div className="text-white/30 text-center mt-20">Listening... Say hello!</div>
                )}
                {transcripts.map((t, i) => (
                    <div key={i} className={`flex ${t.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-2xl p-4 ${
                            t.role === 'user' 
                                ? 'bg-indigo-600 text-white rounded-tr-none' 
                                : 'bg-slate-800 text-slate-200 rounded-tl-none'
                        }`}>
                            {t.text}
                        </div>
                    </div>
                ))}
            </div>

            {/* Controls */}
            <div className="relative z-10 p-6 bg-gradient-to-t from-black to-transparent">
                 <div className="flex justify-center">
                    <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-[0_0_30px_rgba(255,255,255,0.3)]">
                        <svg className="w-8 h-8 text-black" fill="currentColor" viewBox="0 0 24 24"><path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/><path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>
                    </div>
                 </div>
            </div>
        </div>
    );
};