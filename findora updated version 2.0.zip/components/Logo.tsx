import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'small' | 'large';
  onClick?: () => void;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'large', onClick }) => {
  const isLarge = size === 'large';
  
  return (
    <div 
      className={`font-sans font-bold select-none cursor-pointer flex items-center gap-2 ${className}`}
      onClick={onClick}
    >
      <div className={`${isLarge ? 'w-10 h-10' : 'w-8 h-8'} bg-gradient-to-tr from-indigo-600 to-violet-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30`}>
        <svg className="w-2/3 h-2/3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
        </svg>
      </div>
      <span className={`${isLarge ? 'text-4xl' : 'text-2xl'} tracking-tight text-slate-800`}>
        Find<span className="text-indigo-600">ora</span>
      </span>
    </div>
  );
};