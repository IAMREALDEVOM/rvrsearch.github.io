import React from 'react';
import { DashboardData } from '../types';

interface DashboardWidgetsProps {
  data: DashboardData | null;
  loading: boolean;
}

export const DashboardWidgets: React.FC<DashboardWidgetsProps> = ({ data, loading }) => {
  
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl mt-12 px-4 animate-pulse">
        <div className="h-40 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/60 shadow-sm"></div>
        <div className="h-40 bg-white/50 backdrop-blur-sm rounded-2xl border border-white/60 shadow-sm"></div>
      </div>
    );
  }

  if (!data || !data.weather || !data.news) return null;

  const getWeatherIcon = (condition: string) => {
    const c = condition.toLowerCase();
    if (c.includes('rain')) return '🌧️';
    if (c.includes('cloud')) return '☁️';
    if (c.includes('sun') || c.includes('clear')) return '☀️';
    if (c.includes('snow')) return '❄️';
    if (c.includes('storm')) return '⚡';
    return '🌤️';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full max-w-4xl mt-12 px-4 fade-in-up">
      {/* Weather Card */}
      <div className="relative overflow-hidden p-6 bg-white/80 backdrop-blur-md rounded-2xl border border-white/60 shadow-lg shadow-indigo-500/5 hover:shadow-indigo-500/10 transition-shadow">
        <div className="absolute top-0 right-0 p-4 opacity-10">
            <svg className="w-32 h-32" fill="currentColor" viewBox="0 0 24 24"><path d="M6.76 4.84l-1.8-1.79-1.41 1.41 1.79 1.79 1.42-1.41zM4 10.5H1v2h3v-2zm9-9.95h-2V3.5h2V.55zm7.45 3.91l-1.41-1.41-1.79 1.79 1.41 1.41 1.79-1.79zm-3.21 13.7l1.79 1.8 1.41-1.41-1.8-1.79-1.4 1.4zM20 10.5v2h3v-2h-3zm-8-5c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm-1 16.95h2V19.5h-2v2.95zm-7.45-3.91l1.41 1.41 1.79-1.8-1.41-1.41-1.79 1.8z"/></svg>
        </div>
        <div className="relative z-10 flex flex-col h-full justify-between">
            <div>
                <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Current Weather</h3>
                <div className="text-lg font-medium text-slate-800 mt-1">{data.weather.location}</div>
            </div>
            <div className="flex items-center gap-4 mt-4">
                <div className="text-5xl">{getWeatherIcon(data.weather.condition)}</div>
                <div>
                    <div className="text-4xl font-bold text-slate-900">{data.weather.temperature}</div>
                    <div className="text-slate-600">{data.weather.condition}</div>
                </div>
            </div>
        </div>
      </div>

      {/* News Card */}
      <div className="p-6 bg-white/80 backdrop-blur-md rounded-2xl border border-white/60 shadow-lg shadow-indigo-500/5 hover:shadow-indigo-500/10 transition-shadow flex flex-col">
        <h3 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
            Trending News
        </h3>
        <div className="flex flex-col gap-4 flex-grow">
            {data.news.slice(0, 3).map((item, idx) => (
                <div key={idx} className="flex flex-col border-b border-slate-100 last:border-0 pb-3 last:pb-0">
                    <a href={`https://www.google.com/search?q=${encodeURIComponent(item.headline)}`} target="_blank" rel="noreferrer" className="text-sm font-medium text-slate-800 hover:text-indigo-600 transition-colors line-clamp-2">
                        {item.headline}
                    </a>
                    <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                        <span>{item.source}</span>
                        <span>•</span>
                        <span>{item.time}</span>
                    </div>
                </div>
            ))}
            {data.news.length === 0 && (
                <div className="text-slate-400 text-sm">No recent news available.</div>
            )}
        </div>
      </div>
    </div>
  );
};