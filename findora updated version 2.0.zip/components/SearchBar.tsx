import React, { useState, useEffect, useRef } from 'react';

interface SearchBarProps {
  initialQuery?: string;
  onSearch: (query: string) => void;
  centered?: boolean;
}

export const SearchBar: React.FC<SearchBarProps> = ({ initialQuery = '', onSearch, centered = false }) => {
  const [query, setQuery] = useState(initialQuery);
  const [isFocused, setIsFocused] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);
  
  useEffect(() => {
    setQuery(initialQuery);
  }, [initialQuery]);

  // Load history from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('nova_search_history');
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  const saveHistory = (newQuery: string) => {
    const trimmed = newQuery.trim();
    if (!trimmed) return;
    
    // Remove duplicates and add to front, limit to 8 items
    const newHistory = [trimmed, ...history.filter(h => h.toLowerCase() !== trimmed.toLowerCase())].slice(0, 8);
    setHistory(newHistory);
    localStorage.setItem('nova_search_history', JSON.stringify(newHistory));
  };

  const deleteHistoryItem = (e: React.MouseEvent, itemToDelete: string) => {
    e.preventDefault();
    e.stopPropagation();
    const newHistory = history.filter(item => item !== itemToDelete);
    setHistory(newHistory);
    localStorage.setItem('nova_search_history', JSON.stringify(newHistory));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      saveHistory(query);
      onSearch(query);
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
      setIsFocused(false);
    }
  };

  const handleHistoryClick = (item: string) => {
    setQuery(item);
    saveHistory(item);
    onSearch(item);
    setIsFocused(false);
  };

  const toggleVoiceSearch = () => {
    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice search is not supported in this browser.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognitionRef.current = recognition;
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setIsListening(true);
    
    recognition.onend = () => setIsListening(false);
    
    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error);
      setIsListening(false);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript);
      saveHistory(transcript);
      onSearch(transcript);
    };

    recognition.start();
  };

  // Filter history based on current input
  const filteredHistory = query 
    ? history.filter(h => h.toLowerCase().includes(query.toLowerCase()))
    : history;

  const shouldShowDropdown = isFocused && filteredHistory.length > 0;

  return (
    <div className={`w-full relative z-50 ${centered ? 'max-w-2xl' : 'max-w-3xl'}`}>
      <form 
        onSubmit={handleSubmit} 
        className="w-full relative transition-all duration-300"
      >
        <div 
          className={`
            flex items-center w-full border transition-all duration-200 bg-white
            ${shouldShowDropdown 
              ? 'rounded-t-2xl rounded-b-none border-indigo-500 ring-4 ring-indigo-500/10 shadow-xl' 
              : isFocused 
                ? 'rounded-2xl border-indigo-500 ring-4 ring-indigo-500/10 shadow-xl'
                : 'rounded-2xl border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 bg-white/80 backdrop-blur-md'
            }
            ${centered ? 'h-14 px-6' : 'h-12 px-4'}
          `}
        >
          {/* Search Icon */}
          <div className={`mr-4 ${isFocused ? 'text-indigo-500' : 'text-slate-400'}`}>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path fillRule="evenodd" d="M10.5 3.75a6.75 6.75 0 100 13.5 6.75 6.75 0 000-13.5zM2.25 10.5a8.25 8.25 0 1114.59 5.28l4.69 4.69a.75.75 0 11-1.06 1.06l-4.69-4.69A8.25 8.25 0 012.25 10.5z" clipRule="evenodd" />
            </svg>
          </div>

          <input
            type="text"
            value={query}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask anything..."
            className="flex-grow outline-none bg-transparent text-slate-800 placeholder-slate-400 text-base font-medium"
            autoComplete="off"
          />

          {/* Clear Button */}
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="ml-2 p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path fillRule="evenodd" d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25zm-1.72 6.97a.75.75 0 10-1.06 1.06L10.94 12l-1.72 1.72a.75.75 0 101.06 1.06L12 13.06l1.72 1.72a.75.75 0 101.06-1.06L13.06 12l1.72-1.72a.75.75 0 10-1.06-1.06L12 10.94l-1.72-1.72z" clipRule="evenodd" />
              </svg>
            </button>
          )}
          
          {/* Microphone Button */}
          <button
            type="button"
            onClick={toggleVoiceSearch}
            className={`ml-2 p-2 rounded-full transition-colors ${
              isListening 
                ? 'bg-red-50 text-red-500 animate-pulse' 
                : 'text-slate-400 hover:bg-slate-100 hover:text-indigo-500'
            }`}
            title="Search by voice"
          >
            {isListening ? (
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                <path d="M8.25 4.5a3.75 3.75 0 117.5 0v8.25a3.75 3.75 0 11-7.5 0V4.5z" />
                <path d="M6 10.5a.75.75 0 01.75.75v1.5a5.25 5.25 0 1010.5 0v-1.5a.75.75 0 011.5 0v1.5a6.751 6.751 0 01-6 6.709v2.291h3a.75.75 0 010 1.5h-7.5a.75.75 0 010-1.5h3v-2.291a6.751 6.751 0 01-6-6.709v-1.5A.75.75 0 016 10.5z" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" />
              </svg>
            )}
          </button>

          {/* Submit Action */}
          <button 
              type="submit"
              className={`ml-2 p-2 rounded-lg transition-all duration-200 ${query ? 'bg-indigo-600 text-white shadow-md hover:bg-indigo-700' : 'bg-slate-100 text-slate-300 cursor-default'}`}
              disabled={!query}
              onMouseDown={(e) => e.preventDefault()}
          >
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
                   <path fillRule="evenodd" d="M3.75 12a.75.75 0 01.75-.75h13.19l-5.47-5.47a.75.75 0 011.06-1.06l6.75 6.75a.75.75 0 010 1.06l-6.75 6.75a.75.75 0 11-1.06-1.06l5.47-5.47H4.5a.75.75 0 01-.75-.75z" clipRule="evenodd" />
              </svg>
          </button>
        </div>

        {/* History Dropdown */}
        {shouldShowDropdown && (
          <div 
            className="absolute top-full left-0 right-0 bg-white rounded-b-2xl border-x border-b border-indigo-500 shadow-xl overflow-hidden -mt-[2px] pt-2 pb-2 z-50"
            onMouseDown={(e) => e.preventDefault()}
          >
             <div className="absolute top-0 left-4 right-4 h-[1px] bg-slate-100"></div>
             
             {filteredHistory.map((item, index) => (
                 <div 
                    key={index}
                    onClick={() => handleHistoryClick(item)}
                    className="flex items-center px-6 py-3 hover:bg-slate-50 cursor-pointer group"
                 >
                     <div className="mr-4 text-slate-400">
                         <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                         </svg>
                     </div>
                     <span className="flex-grow text-slate-700 font-medium">{item}</span>
                     <button 
                        onClick={(e) => deleteHistoryItem(e, item)}
                        className="text-slate-300 hover:text-red-400 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-all focus:opacity-100"
                        title="Remove from history"
                     >
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-4 h-4">
                            <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
                        </svg>
                     </button>
                 </div>
             ))}
          </div>
        )}
      </form>
    </div>
  );
};