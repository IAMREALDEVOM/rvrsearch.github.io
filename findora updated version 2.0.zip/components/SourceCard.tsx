import React from 'react';
import { GroundingChunk } from '../types';

interface SourceCardProps {
  chunk: GroundingChunk;
  index: number;
}

export const SourceCard: React.FC<SourceCardProps> = ({ chunk, index }) => {
  if (!chunk.web) return null;

  const { title, uri } = chunk.web;
  
  let domain = '';
  try {
    const urlObj = new URL(uri);
    domain = urlObj.hostname.replace('www.', '');
  } catch (e) {
    domain = uri;
  }

  const faviconUrl = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;

  return (
    <a 
      href={uri} 
      target="_blank" 
      rel="noopener noreferrer"
      className="flex flex-col bg-white border border-slate-200 rounded-xl p-4 hover:border-indigo-300 hover:shadow-md transition-all duration-200 h-full group"
    >
      <div className="flex items-center mb-3">
        <div className="w-8 h-8 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center overflow-hidden shrink-0">
           <img src={faviconUrl} alt="" className="w-4 h-4 object-contain opacity-80 group-hover:opacity-100" />
        </div>
        <div className="ml-3 overflow-hidden">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider truncate">{domain}</div>
        </div>
      </div>
      <h3 className="text-sm font-medium text-slate-900 group-hover:text-indigo-600 line-clamp-2 leading-relaxed">
        {title}
      </h3>
    </a>
  );
};